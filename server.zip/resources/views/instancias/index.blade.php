@extends('layouts.app')

@section('content')

<div class="panel-header">
    <div>
        <h1 class="panel-title">Minhas Instâncias (WhatsApp)</h1>
        <p class="panel-subtitle">Gerencie as conexões da Evolution/WhatsApp e controle o envio diário.</p>
    </div>

    <a href="{{ route('instancias.create') }}" class="z-btn z-btn-primary">
        + Nova instância
    </a>
</div>

@if (session('success'))
    <div class="z-card" style="margin-bottom:14px;">
        <div class="z-card-body">
            <div class="z-badge z-badge-ok">✅ {{ session('success') }}</div>
        </div>
    </div>
@endif

@if (session('error'))
    <div class="z-card" style="margin-bottom:14px;">
        <div class="z-card-body">
            <div class="z-badge z-badge-off">⛔ {{ session('error') }}</div>
        </div>
    </div>
@endif

@if (session('info'))
    <div class="z-card" style="margin-bottom:14px;">
        <div class="z-card-body">
            <div class="z-badge z-badge-warn">ℹ️ {{ session('info') }}</div>
        </div>
    </div>
@endif

<div class="z-card">
    <div class="z-card-header">
        <strong>Lista de Instâncias</strong>
        <div style="display:flex;gap:10px;align-items:center;">
            <span style="font-size:12px;color:var(--muted);">Total: {{ $instances->count() }}</span>
        </div>
    </div>

    <div class="z-card-body" style="padding:0;">
        <table class="z-table">
            <thead>
                <tr>
                    <th>Label</th>
                    <th>Instance</th>
                    <th>Ativa</th>
                    <th>Limite/dia</th>
                    <th>Status (Evo)</th>
                    <th style="width: 320px;">Ações</th>
                </tr>
            </thead>

            <tbody>
            @forelse ($instances as $row)
                <tr>
                    <td>
                        {{ $row->label ?? '-' }}
                    </td>

                    <td>
                        <strong>{{ $row->instance_name }}</strong>
                    </td>

                    <td>
                        @if ((bool)$row->enabled)
                            <span class="z-badge z-badge-ok">SIM</span>
                        @else
                            <span class="z-badge z-badge-warn">NÃO</span>
                        @endif
                    </td>

                    <td>
                        {{ (int)($row->daily_limit ?? 200) }}
                    </td>

                    <td>
                        <span style="font-size:12px;color:var(--muted);">-</span>
                    </td>

                    <td>
                        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">

                            {{-- Conectar (gera QR / inicia sessão na Evolution) --}}
                            <form method="POST" action="{{ route('instancias.connect', $row->id) }}">
                                @csrf
                                <button type="submit" class="z-btn z-btn-primary">
                                    Conectar
                                </button>
                            </form>

                            {{-- Ativar/Desativar (enabled) --}}
                            <form method="POST" action="{{ route('instancias.toggle', $row->id) }}">
                                @csrf
                                <button type="submit" class="z-btn">
                                    {{ ((bool)$row->enabled) ? 'Desativar' : 'Ativar' }}
                                </button>
                            </form>

                            {{-- Remover --}}
                            <form method="POST"
                                  action="{{ route('instancias.destroy', $row->id) }}"
                                  onsubmit="return confirm('Remover esta instância?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="z-btn z-btn-danger">
                                    Remover
                                </button>
                            </form>

                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="6" style="padding:16px 12px;color:var(--muted);">
                        Nenhuma instância cadastrada ainda. Clique em <strong>+ Nova instância</strong>.
                    </td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>

@if (app()->environment('local'))
    <div style="margin-top:14px;font-size:12px;color:var(--muted);">
        Debug local:
        <a class="link" href="{{ url('/evolution/ping') }}">/evolution/ping</a>
        ·
        <a class="link" href="{{ url('/evolution/check') }}">/evolution/check</a>
    </div>
@endif

@endsection
