<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    protected $fillable = [
        'chat_id',
        'contact_id',
        'provider_message_id',
        'direction',
        'type',
        'body',
        'status',
        'message_at',
        'raw',
    ];

    protected $casts = [
        'raw' => 'array',
        'message_at' => 'datetime',
    ];

    public function chat()
    {
        return $this->belongsTo(Chat::class);
    }
}
