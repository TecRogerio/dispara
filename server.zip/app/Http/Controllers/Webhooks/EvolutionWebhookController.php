<?php

namespace App\Http\Controllers\Webhooks;

use App\Http\Controllers\Controller;
use App\Models\Chat;
use App\Models\Message;
use App\Models\WhatsappInstance;
use App\Models\Contact;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class EvolutionWebhookController extends Controller
{
    public function handle(Request $request)
    {
        // 1) Validação do SECRET (aceita header ou query token)
        $secret = (string) env('EVOLUTION_WEBHOOK_SECRET', '');
        if ($secret === '') {
            // sem secret configurado => inseguro. Retorna 500 pra você perceber.
            return response()->json(['error' => 'Webhook secret not configured'], 500);
        }

        $provided =
            (string) $request->header('x-evolution-secret', '') ?:
            (string) $request->header('x-webhook-secret', '') ?:
            (string) $request->header('x-agendeizap-secret', '') ?:
            (string) $request->query('token', '');

        if ($provided === '' || !hash_equals($secret, $provided)) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        // 2) Payload
        $payload = $request->all();

        // 3) Descobrir instance_name
        $instanceName =
            data_get($payload, 'instance') ?:
            data_get($payload, 'instanceName') ?:
            data_get($payload, 'data.instance') ?:
            data_get($payload, 'data.instanceName') ?:
            data_get($payload, 'body.instance') ?:
            data_get($payload, 'body.instanceName');

        $instanceName = is_string($instanceName) ? trim($instanceName) : null;

        if (!$instanceName) {
            Log::warning('Evolution webhook: instance_name ausente', ['payload_keys' => array_keys($payload)]);
            // 202 = aceito, mas não processado (evita retries agressivos)
            return response()->json(['ok' => true, 'ignored' => 'missing_instance'], 202);
        }

        /** @var WhatsappInstance|null $instance */
        $instance = WhatsappInstance::where('instance_name', $instanceName)->first();

        if (!$instance) {
            Log::warning('Evolution webhook: instância não encontrada no banco', ['instance' => $instanceName]);
            return response()->json(['ok' => true, 'ignored' => 'unknown_instance'], 202);
        }

        // 4) Extrair dados de mensagem (tolerante)
        // Tentamos achar o “remote_jid” e o texto em vários formatos
        $remoteJid =
            data_get($payload, 'data.key.remoteJid') ?:
            data_get($payload, 'data.remoteJid') ?:
            data_get($payload, 'body.data.key.remoteJid') ?:
            data_get($payload, 'body.remoteJid') ?:
            data_get($payload, 'remoteJid');

        $remoteJid = is_string($remoteJid) ? trim($remoteJid) : null;

        // Texto (quando for mensagem de texto)
        $text =
            data_get($payload, 'data.message.conversation') ?:
            data_get($payload, 'data.message.extendedTextMessage.text') ?:
            data_get($payload, 'data.text') ?:
            data_get($payload, 'message.text') ?:
            data_get($payload, 'body.data.message.conversation') ?:
            data_get($payload, 'body.data.message.extendedTextMessage.text');

        $text = is_string($text) ? trim($text) : null;

        // ID da mensagem
        $providerMessageId =
            data_get($payload, 'data.key.id') ?:
            data_get($payload, 'data.id') ?:
            data_get($payload, 'message.id') ?:
            data_get($payload, 'body.data.key.id');

        $providerMessageId = is_string($providerMessageId) ? trim($providerMessageId) : null;

        // Timestamp (segundos unix ou ISO)
        $ts =
            data_get($payload, 'data.messageTimestamp') ?:
            data_get($payload, 'data.timestamp') ?:
            data_get($payload, 'timestamp') ?:
            data_get($payload, 'body.data.messageTimestamp');

        $messageAt = $this->parseTimestamp($ts);

        // Tipo
        $type = 'text';
        if (!$text) {
            // se não achou texto, marca unknown (você pode ampliar depois p/ mídia)
            $type = 'unknown';
        }

        // Se ainda não temos jid, não temos como criar chat
        if (!$remoteJid) {
            Log::warning('Evolution webhook: remote_jid ausente', ['instance' => $instanceName]);
            return response()->json(['ok' => true, 'ignored' => 'missing_remote_jid'], 202);
        }

        // 5) Criar / atualizar Contact (opcional, mas ajuda pro chat)
        $contactId = null;
        try {
            $phoneDigits = $this->jidToDigits($remoteJid);

            if ($phoneDigits) {
                $phoneE164 = $phoneDigits; // no seu padrão: E.164 sem '+'
                $contact = Contact::updateOrCreate(
                    ['tenant_id' => 1, 'phone_e164' => $phoneE164],
                    [
                        'name' => data_get($payload, 'data.pushName')
                            ?: data_get($payload, 'pushName')
                            ?: data_get($payload, 'sender.name')
                            ?: null,
                        'pushname' => data_get($payload, 'data.pushName') ?: null,
                        'phone_raw' => $phoneDigits,
                        'is_group' => str_contains($remoteJid, '@g.us'),
                    ]
                );
                $contactId = $contact->id;
            }
        } catch (\Throwable $e) {
            Log::warning('Evolution webhook: falha ao upsert contact', ['err' => $e->getMessage()]);
        }

        // 6) Chat upsert
        $chat = Chat::updateOrCreate(
            [
                'whatsapp_instance_id' => $instance->id,
                'remote_jid' => $remoteJid,
            ],
            [
                'user_id' => $instance->user_id,
                'title' => data_get($payload, 'data.pushName')
                    ?: data_get($payload, 'pushName')
                    ?: null,
                'last_message_at' => $messageAt ?: now(),
            ]
        );

        // 7) Evitar duplicado por provider_message_id (idempotência)
        if ($providerMessageId) {
            $exists = Message::where('chat_id', $chat->id)
                ->where('provider_message_id', $providerMessageId)
                ->exists();

            if ($exists) {
                return response()->json(['ok' => true, 'dedup' => true]);
            }
        }

        // 8) Salvar Message
        Message::create([
            'chat_id' => $chat->id,
            'contact_id' => $contactId,
            'provider_message_id' => $providerMessageId,
            'direction' => 'inbound',
            'type' => $type,
            'body' => $text,
            'status' => 'received',
            'message_at' => $messageAt,
            'raw' => $payload,
        ]);

        return response()->json(['ok' => true]);
    }

    private function parseTimestamp($ts): ?Carbon
    {
        try {
            if (is_numeric($ts)) {
                // alguns payloads vêm em segundos, outros em ms
                $n = (int) $ts;
                if ($n > 2000000000) { // ms
                    return Carbon::createFromTimestampMs($n);
                }
                return Carbon::createFromTimestamp($n);
            }

            if (is_string($ts) && trim($ts) !== '') {
                return Carbon::parse($ts);
            }
        } catch (\Throwable $e) {
            // ignora
        }
        return null;
    }

    private function jidToDigits(string $jid): ?string
    {
        // 5547999999999@s.whatsapp.net -> 5547999999999
        // 5547xxxx@g.us -> 5547xxxx (pra grupo não é perfeito, mas ok)
        $base = explode('@', $jid)[0] ?? '';
        $digits = preg_replace('/\D+/', '', $base);
        $digits = is_string($digits) ? $digits : '';
        return $digits !== '' ? $digits : null;
    }
}
