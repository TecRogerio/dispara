<?php

namespace App\Http\Controllers;

use App\Models\Chat;
use App\Models\Message;
use App\Models\WhatsappInstance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ChatController extends Controller
{
    public function index(Request $request)
    {
        $userId = Auth::id();
        $q = trim((string) $request->get('q', ''));

        $chats = Chat::query()
            ->where('user_id', $userId)
            ->when($q !== '', function ($query) use ($q) {
                $query->where(function ($qq) use ($q) {
                    $qq->where('remote_jid', 'like', "%{$q}%")
                       ->orWhere('title', 'like', "%{$q}%");
                });
            })
            ->orderByDesc('last_message_at')
            ->orderByDesc('id')
            ->paginate(20)
            ->withQueryString();

        return view('chats.index', compact('chats', 'q'));
    }

    public function show(Chat $chat)
    {
        abort_unless((int) $chat->user_id === (int) Auth::id(), 403);

        $messages = Message::query()
            ->where('chat_id', $chat->id)
            ->orderByDesc('message_at')
            ->orderByDesc('id')
            ->paginate(50)
            ->withQueryString();

        return view('chats.show', compact('chat', 'messages'));
    }

    public function send(Request $request, Chat $chat)
    {
        abort_unless((int) $chat->user_id === (int) Auth::id(), 403);

        $data = $request->validate([
            'text' => ['required', 'string', 'min:1', 'max:4000'],
        ]);

        $text = trim($data['text']);

        // Pega a instância vinculada ao chat (ou tenta a ativa do usuário)
        $instance = WhatsappInstance::query()
            ->where('id', $chat->whatsapp_instance_id)
            ->where('user_id', Auth::id())
            ->first();

        if (!$instance) {
            $instance = WhatsappInstance::query()
                ->where('user_id', Auth::id())
                ->where('is_active', 1)
                ->orderByDesc('id')
                ->first();
        }

        if (!$instance) {
            return back()->with('error', 'Nenhuma instância ativa encontrada para enviar mensagens.');
        }

        // Envia via Evolution (endpoint pode variar; aqui tentamos caminhos comuns e falhamos com mensagem clara)
        $baseUrl = rtrim((string) config('evolution.base_url'), '/');
        $apiKey  = (string) config('evolution.api_key');
        $timeout = (int) config('evolution.timeout', 30);

        if (!$baseUrl || !$apiKey) {
            return back()->with('error', 'Evolution não configurada (EVOLUTION_BASE_URL/EVOLUTION_API_KEY).');
        }

        $payload = [
            // muitos provedores usam "number"/"remoteJid" – aqui usamos remoteJid que é o padrão do JID
            'remoteJid' => $chat->remote_jid,
            'text'      => $text,
        ];

        // caminhos mais comuns (a tua Evolution pode usar um destes)
        $tryPaths = [
            "/message/sendText/{$instance->instance_name}",
            "/messages/sendText/{$instance->instance_name}",
            "/sendText/{$instance->instance_name}",
        ];

        $sentOk = false;
        $respBody = null;

        foreach ($tryPaths as $path) {
            try {
                $resp = Http::timeout($timeout)
                    ->withHeaders([
                        'apikey' => $apiKey,
                        'Accept' => 'application/json',
                    ])
                    ->post($baseUrl . $path, $payload);

                $respBody = $resp->json() ?? $resp->body();

                if ($resp->successful()) {
                    $sentOk = true;
                    break;
                }
            } catch (\Throwable $e) {
                Log::warning('Chat send try failed', [
                    'path' => $path,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        // Salva no banco mesmo se falhar (pra log/UX)
        Message::create([
            'chat_id'             => $chat->id,
            'contact_id'          => null, // se você tiver contato amarrado, dá pra preencher
            'provider_message_id' => null,
            'direction'           => 'outbound',
            'type'                => 'text',
            'body'                => $text,
            'status'              => $sentOk ? 'sent' : 'failed',
            'message_at'          => now(),
            'raw'                 => is_string($respBody) ? $respBody : json_encode($respBody, JSON_UNESCAPED_UNICODE),
        ]);

        // atualiza “última msg” do chat
        $chat->last_message_at = now();
        $chat->save();

        return redirect()
            ->route('chats.show', $chat->id)
            ->with($sentOk ? 'success' : 'error', $sentOk ? 'Mensagem enviada.' : 'Falha ao enviar pela Evolution (verifique endpoints/instância).');
    }

    /**
     * Sync manual:
     * - Não tenta “puxar histórico” (sua Evolution não expõe endpoint de chats/mensagens no /evolution/check)
     * - Serve para validar configuração e garantir que o realtime via Webhook está OK.
     */
    public function sync(Request $request)
    {
        $userId = Auth::id();

        $instance = WhatsappInstance::query()
            ->where('user_id', $userId)
            ->where('is_active', 1)
            ->orderByDesc('id')
            ->first();

        if (!$instance) {
            return back()->with('error', 'Você não tem instância ativa para sincronizar.');
        }

        $baseUrl = rtrim((string) config('evolution.base_url'), '/');
        $apiKey  = (string) config('evolution.api_key');
        $timeout = (int) config('evolution.timeout', 30);

        if (!$baseUrl || !$apiKey) {
            return back()->with('error', 'Evolution não configurada (EVOLUTION_BASE_URL/EVOLUTION_API_KEY).');
        }

        // Só “ping/version” porque é o que teu /evolution/check confirmou que existe em JSON
        try {
            $ping = Http::timeout($timeout)->withHeaders(['apikey' => $apiKey, 'Accept' => 'application/json'])
                ->get($baseUrl . '/');

            $ver = Http::timeout($timeout)->withHeaders(['apikey' => $apiKey, 'Accept' => 'application/json'])
                ->get($baseUrl . '/version');

            if (!$ping->successful()) {
                return back()->with('error', 'Evolution não respondeu OK no endpoint /.');
            }

            // Marca um “sinal de vida” local (se tua tabela tiver updated_at já ajuda)
            $instance->touch();

            return back()->with(
                'success',
                'Sync OK: Evolution respondeu e instância está ativa. Mensagens entram em tempo real via Webhook (histórico não é importado automaticamente).'
            );
        } catch (\Throwable $e) {
            return back()->with('error', 'Erro ao sincronizar: ' . $e->getMessage());
        }
    }
}
