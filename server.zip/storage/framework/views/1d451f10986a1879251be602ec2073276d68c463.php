<?php $__env->startSection('content'); ?>

<div class="panel-header">
    <div>
        <h1 class="panel-title">Minhas Instâncias (WhatsApp)</h1>
        <p class="panel-subtitle">Gerencie as conexões da Evolution/WhatsApp e controle o envio diário.</p>
    </div>

    <a href="<?php echo e(route('instancias.create')); ?>" class="z-btn z-btn-primary">
        + Nova instância
    </a>
</div>

<?php if(session('success')): ?>
    <div class="z-card" style="margin-bottom:14px;">
        <div class="z-card-body">
            <div class="z-badge z-badge-ok">✅ <?php echo e(session('success')); ?></div>
        </div>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="z-card" style="margin-bottom:14px;">
        <div class="z-card-body">
            <div class="z-badge z-badge-off">⛔ <?php echo e(session('error')); ?></div>
        </div>
    </div>
<?php endif; ?>

<?php if(session('info')): ?>
    <div class="z-card" style="margin-bottom:14px;">
        <div class="z-card-body">
            <div class="z-badge z-badge-warn">ℹ️ <?php echo e(session('info')); ?></div>
        </div>
    </div>
<?php endif; ?>

<div class="z-card">
    <div class="z-card-header">
        <strong>Lista de Instâncias</strong>
        <div style="display:flex;gap:10px;align-items:center;">
            <span style="font-size:12px;color:var(--muted);">Total: <?php echo e($instances->count()); ?></span>
        </div>
    </div>

    <div class="z-card-body" style="padding:0;">
        <table class="z-table">
            <thead>
                <tr>
                    <th>Label</th>
                    <th>Instance</th>
                    <th>Ativa</th>
                    <th>Limite/dia</th>
                    <th>Status (Evo)</th>
                    <th style="width: 320px;">Ações</th>
                </tr>
            </thead>

            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $instances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php echo e($row->label ?? '-'); ?>

                    </td>

                    <td>
                        <strong><?php echo e($row->instance_name); ?></strong>
                    </td>

                    <td>
                        <?php if((bool)$row->enabled): ?>
                            <span class="z-badge z-badge-ok">SIM</span>
                        <?php else: ?>
                            <span class="z-badge z-badge-warn">NÃO</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php echo e((int)($row->daily_limit ?? 200)); ?>

                    </td>

                    <td>
                        <span style="font-size:12px;color:var(--muted);">-</span>
                    </td>

                    <td>
                        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">

                            
                            <form method="POST" action="<?php echo e(route('instancias.connect', $row->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="z-btn z-btn-primary">
                                    Conectar
                                </button>
                            </form>

                            
                            <form method="POST" action="<?php echo e(route('instancias.toggle', $row->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="z-btn">
                                    <?php echo e(((bool)$row->enabled) ? 'Desativar' : 'Ativar'); ?>

                                </button>
                            </form>

                            
                            <form method="POST"
                                  action="<?php echo e(route('instancias.destroy', $row->id)); ?>"
                                  onsubmit="return confirm('Remover esta instância?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="z-btn z-btn-danger">
                                    Remover
                                </button>
                            </form>

                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" style="padding:16px 12px;color:var(--muted);">
                        Nenhuma instância cadastrada ainda. Clique em <strong>+ Nova instância</strong>.
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if(app()->environment('local')): ?>
    <div style="margin-top:14px;font-size:12px;color:var(--muted);">
        Debug local:
        <a class="link" href="<?php echo e(url('/evolution/ping')); ?>">/evolution/ping</a>
        ·
        <a class="link" href="<?php echo e(url('/evolution/check')); ?>">/evolution/check</a>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dispara\resources\views/instancias/index.blade.php ENDPATH**/ ?>