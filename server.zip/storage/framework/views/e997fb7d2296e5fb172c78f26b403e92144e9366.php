

<?php $__env->startSection('content'); ?>

<div class="panel-header">
  <div>
    <h1 class="panel-title">Campanhas</h1>
    <p class="panel-subtitle">Gerencie suas campanhas, mensagens e disparos.</p>
  </div>

  <div style="display:flex;gap:10px;flex-wrap:wrap;">
    <a href="<?php echo e(route('campanhas.create')); ?>" class="z-btn z-btn-primary">
      + Nova campanha
    </a>
  </div>
</div>

<?php if(session('success')): ?>
  <div class="z-card" style="margin-bottom:14px;">
    <div class="z-card-body">
      <div class="z-badge z-badge-ok">✅ <?php echo e(session('success')); ?></div>
    </div>
  </div>
<?php endif; ?>

<?php if(session('error')): ?>
  <div class="z-card" style="margin-bottom:14px;">
    <div class="z-card-body">
      <div class="z-badge z-badge-off">⛔ <?php echo e(session('error')); ?></div>
    </div>
  </div>
<?php endif; ?>


<div class="d-none d-md-block">
  <div class="z-card">
    <div class="z-card-header">
      <strong>Lista de campanhas</strong>
      <div style="display:flex;gap:10px;align-items:center;">
        <span style="font-size:12px;color:var(--muted);">Total: <?php echo e($campaigns->count()); ?></span>
      </div>
    </div>

    <div class="z-card-body" style="padding:0;">
      <table class="z-table">
        <thead>
          <tr>
            <th>Campanha</th>
            <th>Status</th>
            <th>Instância</th>
            <th>Criada</th>
            <th style="text-align:right;width:160px;">Ações</th>
          </tr>
        </thead>

        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
            $status = $c->status ?? 'draft';

            // Badge do tema (sem bootstrap)
            $badgeClass = 'z-badge';
            if ($status === 'running') $badgeClass .= ' z-badge-warn';
            elseif ($status === 'finished') $badgeClass .= ' z-badge-ok';
            elseif ($status === 'failed') $badgeClass .= ' z-badge-off';
            elseif ($status === 'paused') $badgeClass .= ' z-badge-warn';

            $instanceLabel = optional($c->instance)->label ?? optional($c->instance)->instance_name ?? '-';
          ?>

          <tr>
            <td>
              <div style="display:flex;flex-direction:column;gap:2px;">
                <a href="<?php echo e(route('campanhas.show', $c->id)); ?>"
                   class="link"
                   style="font-weight:900; font-size:14px;">
                  <?php echo e($c->name); ?>

                </a>
                <span style="font-size:12px;color:var(--muted);">ID #<?php echo e($c->id); ?></span>
              </div>
            </td>

            <td>
              <span class="<?php echo e($badgeClass); ?>"><?php echo e($status); ?></span>
            </td>

            <td>
              <div style="display:flex;flex-direction:column;gap:2px;">
                <span style="font-weight:800;"><?php echo e($instanceLabel); ?></span>
                <?php if(optional($c->instance)->instance_name): ?>
                  <span style="font-size:12px;color:var(--muted);"><?php echo e($c->instance->instance_name); ?></span>
                <?php endif; ?>
              </div>
            </td>

            <td>
              <div style="display:flex;flex-direction:column;gap:2px;">
                <span style="font-weight:800;">
                  <?php echo e(optional($c->created_at)->format('d/m/Y') ?? '-'); ?>

                </span>
                <span style="font-size:12px;color:var(--muted);">
                  <?php echo e(optional($c->created_at)->format('H:i') ?? ''); ?>

                </span>
              </div>
            </td>

            <td style="text-align:right;">
              <a href="<?php echo e(route('campanhas.show', $c->id)); ?>" class="z-btn">
                Abrir
              </a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="5" style="padding:16px 12px;color:var(--muted);">
              Nenhuma campanha ainda.
            </td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>


<div class="d-md-none">
  <div style="display:grid;gap:12px;">
    <?php $__empty_1 = true; $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <?php
        $status = $c->status ?? 'draft';
        $badgeClass = 'z-badge';
        if ($status === 'running') $badgeClass .= ' z-badge-warn';
        elseif ($status === 'finished') $badgeClass .= ' z-badge-ok';
        elseif ($status === 'failed') $badgeClass .= ' z-badge-off';
        elseif ($status === 'paused') $badgeClass .= ' z-badge-warn';

        $instanceLabel = optional($c->instance)->label ?? optional($c->instance)->instance_name ?? '-';
      ?>

      <div class="z-card">
        <div class="z-card-body">
          <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;">
            <div style="min-width:0;">
              <div style="font-weight:900;font-size:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                <?php echo e($c->name); ?>

              </div>
              <div style="font-size:12px;color:var(--muted);">ID #<?php echo e($c->id); ?></div>
            </div>
            <span class="<?php echo e($badgeClass); ?>"><?php echo e($status); ?></span>
          </div>

          <div style="margin-top:10px;font-size:13px;color:var(--muted);line-height:1.5;">
            <div><strong style="color:rgba(229,231,235,.92);">Instância:</strong> <?php echo e($instanceLabel); ?></div>
            <div><strong style="color:rgba(229,231,235,.92);">Criada:</strong> <?php echo e(optional($c->created_at)->format('d/m/Y H:i') ?? '-'); ?></div>
          </div>

          <div style="margin-top:12px;">
            <a href="<?php echo e(route('campanhas.show', $c->id)); ?>" class="z-btn" style="width:100%;justify-content:center;">
              Abrir campanha
            </a>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div style="color:var(--muted);">Nenhuma campanha ainda.</div>
    <?php endif; ?>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dispara\resources\views/campanhas/index.blade.php ENDPATH**/ ?>