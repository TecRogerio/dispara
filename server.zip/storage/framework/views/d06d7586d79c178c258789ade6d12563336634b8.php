

<?php $__env->startSection('content'); ?>
<?php
  // $chat, $messages, $messagesAsc, $chats vem do controller
?>

<style>
  .chat-shell{ display:grid; grid-template-columns: 360px 1fr; gap:14px; }
  .chat-list{ height: calc(100vh - 210px); overflow:auto; }
  .chat-thread{ height: calc(100vh - 210px); overflow:auto; padding:16px; }
  .chat-item{
    display:block; padding:12px 12px; border-radius:14px; text-decoration:none;
    border:1px solid rgba(15,23,42,.08); background: rgba(15,23,42,.02);
    transition:.12s;
  }
  .chat-item:hover{ transform: translateY(-1px); border-color: rgba(37,99,235,.20); background: rgba(37,99,235,.06); }
  .chat-item.active{ border-color: rgba(37,99,235,.30); background: rgba(37,99,235,.10); }
  .bubble{
    max-width: 680px; padding:10px 12px; border-radius:16px; border:1px solid rgba(15,23,42,.10);
    box-shadow: 0 8px 20px rgba(15,23,42,.06);
    white-space: pre-wrap;
  }
  .bubble.in{ background:#fff; }
  .bubble.out{ background: rgba(37,99,235,.10); border-color: rgba(37,99,235,.22); }
  .msg-row{ display:flex; gap:10px; margin-bottom:10px; }
  .msg-row.in{ justify-content:flex-start; }
  .msg-row.out{ justify-content:flex-end; }
  .msg-meta{ font-size:11px; color: var(--muted); margin-top:4px; font-weight:700; }
  .composer{ display:flex; gap:10px; }
  .composer textarea{ resize:none; min-height: 44px; max-height: 120px; }
  @media (max-width: 980px){
    .chat-shell{ grid-template-columns: 1fr; }
    .chat-list{ height:auto; max-height: 280px; }
    .chat-thread{ height:auto; max-height: 420px; }
  }
</style>

<div class="panel-header">
  <div>
    <h1 class="panel-title">Conversa</h1>
    <p class="panel-subtitle">
      <strong><?php echo e($chat->title ?: $chat->remote_jid); ?></strong>
      · <?php echo e($chat->remote_jid); ?>

    </p>
  </div>

  <a href="<?php echo e(route('chats.index')); ?>" class="z-btn">← Voltar</a>
</div>

<?php if(session('success')): ?>
  <div class="z-card" style="margin-bottom:14px;">
    <div class="z-card-body">
      <div class="z-badge z-badge-ok">✅ <?php echo e(session('success')); ?></div>
    </div>
  </div>
<?php endif; ?>

<?php if(session('error')): ?>
  <div class="z-card" style="margin-bottom:14px;">
    <div class="z-card-body">
      <div class="z-badge z-badge-off">⛔ <?php echo e(session('error')); ?></div>
    </div>
  </div>
<?php endif; ?>

<?php if($errors->any()): ?>
  <div class="z-card" style="margin-bottom:14px;">
    <div class="z-card-body">
      <div class="z-badge z-badge-off">⛔ <?php echo e($errors->first()); ?></div>
    </div>
  </div>
<?php endif; ?>

<div class="chat-shell">

  
  <div class="z-card">
    <div class="z-card-header">
      <strong>Conversas</strong>
      <span style="font-size:12px;color:var(--muted);">últimas 50</span>
    </div>

    <div class="z-card-body chat-list" style="display:grid; gap:10px;">
      <?php $__empty_1 = true; $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
          $active = ((int)$c->id === (int)$chat->id);
          $title = $c->title ?: $c->remote_jid;
          $lastAt = $c->last_message_at ? \Carbon\Carbon::parse($c->last_message_at)->format('d/m H:i') : '-';
        ?>

        <a href="<?php echo e(route('chats.show', $c->id)); ?>" class="chat-item <?php echo e($active ? 'active' : ''); ?>">
          <div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start;">
            <div style="min-width:0;">
              <div style="font-weight:900; color: var(--text); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                <?php echo e($title); ?>

              </div>
              <div style="font-size:12px;color:var(--muted); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                <?php echo e($c->remote_jid); ?>

              </div>
            </div>
            <div style="font-size:11px;color:var(--muted);font-weight:800;">
              <?php echo e($lastAt); ?>

            </div>
          </div>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div style="color:var(--muted);">Nenhuma conversa.</div>
      <?php endif; ?>
    </div>
  </div>

  
  <div class="z-card">
    <div class="z-card-header">
      <strong>Mensagens</strong>
      <span style="font-size:12px;color:var(--muted);">
        Chat #<?php echo e($chat->id); ?>

      </span>
    </div>

    <div class="chat-thread" id="chatThread">
      <?php $__empty_1 = true; $__currentLoopData = $messagesAsc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
          $isOut = ($m->direction === 'outbound');
          $when = $m->message_at ? \Carbon\Carbon::parse($m->message_at)->format('d/m/Y H:i') : '';
          $status = $m->status ?? '';
        ?>

        <div class="msg-row <?php echo e($isOut ? 'out' : 'in'); ?>">
          <div>
            <div class="bubble <?php echo e($isOut ? 'out' : 'in'); ?>">
              <?php echo e($m->body); ?>

            </div>
            <div class="msg-meta" style="<?php echo e($isOut ? 'text-align:right;' : ''); ?>">
              <?php echo e($when); ?> <?php if($isOut && $status): ?> · <?php echo e($status); ?> <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div style="color:var(--muted); padding:14px;">
          Nenhuma mensagem ainda.
        </div>
      <?php endif; ?>
    </div>

    <div class="z-card-body" style="border-top:1px solid rgba(15,23,42,.08);">
      <form method="POST" action="<?php echo e(route('chats.send', $chat->id)); ?>">
        <?php echo csrf_field(); ?>
        <div class="composer">
          <textarea
            class="z-input"
            name="text"
            placeholder="Digite uma mensagem..."
            rows="2"
            style="flex:1;"
            required
          ><?php echo e(old('text')); ?></textarea>

          <button type="submit" class="z-btn z-btn-primary" style="min-width:140px;">
            Enviar
          </button>
        </div>
        <div style="margin-top:8px; font-size:12px; color: var(--muted);">
          Envio via Evolution (texto). Em seguida faremos “tempo real” com WebSocket.
        </div>
      </form>

      <?php if(method_exists($messages, 'links')): ?>
        <div style="margin-top:12px;">
          <?php echo e($messages->links()); ?>

        </div>
      <?php endif; ?>
    </div>
  </div>

</div>

<script>
  // desce pro final automaticamente ao abrir
  (function(){
    const el = document.getElementById('chatThread');
    if(el) el.scrollTop = el.scrollHeight;
  })();
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dispara\resources\views/chats/show.blade.php ENDPATH**/ ?>