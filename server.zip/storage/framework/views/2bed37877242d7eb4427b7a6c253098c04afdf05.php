

<?php $__env->startSection('content'); ?>
<?php
  // $chats, $q, $lastByChat vem do controller
?>

<div class="panel-header">
  <div>
    <h1 class="panel-title">Conversas</h1>
    <p class="panel-subtitle">Inbox do WhatsApp — clique em uma conversa para abrir.</p>
  </div>

  <form method="GET" action="<?php echo e(route('chats.index')); ?>" style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
    <input
      name="q"
      value="<?php echo e($q ?? ''); ?>"
      placeholder="Buscar por número / título…"
      class="z-input"
      style="width:280px; max-width: 100%;"
    />
    <button class="z-btn" type="submit">Buscar</button>
  </form>
</div>

<?php if(session('success')): ?>
  <div class="z-card" style="margin-bottom:14px;">
    <div class="z-card-body">
      <div class="z-badge z-badge-ok">✅ <?php echo e(session('success')); ?></div>
    </div>
  </div>
<?php endif; ?>

<?php if(session('error')): ?>
  <div class="z-card" style="margin-bottom:14px;">
    <div class="z-card-body">
      <div class="z-badge z-badge-off">⛔ <?php echo e(session('error')); ?></div>
    </div>
  </div>
<?php endif; ?>

<div class="z-card">
  <div class="z-card-header">
    <strong>Lista de conversas</strong>
    <span style="font-size:12px;color:var(--muted);">
      Total: <?php echo e(method_exists($chats,'total') ? $chats->total() : $chats->count()); ?>

    </span>
  </div>

  <div class="z-card-body" style="padding:0;">
    <table class="z-table">
      <thead>
        <tr>
          <th>Contato</th>
          <th>Última mensagem</th>
          <th style="width:160px;">Data</th>
          <th style="width:140px;">Ações</th>
        </tr>
      </thead>
      <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
          $last = $lastByChat[$c->id] ?? null;

          $title = $c->title ?: $c->remote_jid;
          $subtitle = $c->remote_jid;

          $lastText = $last?->body ?? '-';
          $lastAt = $c->last_message_at ? \Carbon\Carbon::parse($c->last_message_at)->format('d/m/Y H:i') : '-';
          $dir = $last?->direction ?? null;
        ?>

        <tr>
          <td>
            <div style="font-weight:900; color: var(--text);"><?php echo e($title); ?></div>
            <div style="font-size:12px; color: var(--muted);"><?php echo e($subtitle); ?></div>
          </td>

          <td>
            <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
              <?php if($dir === 'inbound'): ?>
                <span class="z-badge z-badge-warn">⬅ recebida</span>
              <?php elseif($dir === 'outbound'): ?>
                <span class="z-badge z-badge-ok">➡ enviada</span>
              <?php endif; ?>

              <span style="color:var(--text);">
                <?php echo e(\Illuminate\Support\Str::limit((string)$lastText, 90)); ?>

              </span>
            </div>
          </td>

          <td style="color:var(--muted); font-weight:700;">
            <?php echo e($lastAt); ?>

          </td>

          <td>
            <a class="z-btn" href="<?php echo e(route('chats.show', $c->id)); ?>">Abrir</a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="4" style="padding:16px;color:var(--muted);">
            Nenhuma conversa encontrada.
          </td>
        </tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php if(method_exists($chats, 'links')): ?>
  <div style="margin-top:14px;">
    <?php echo e($chats->links()); ?>

  </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dispara\resources\views/chats/index.blade.php ENDPATH**/ ?>